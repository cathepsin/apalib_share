def add(num1, num2):
    return num1 + num2

def subtract(num1, num2):
    return num1 - num2

def mult(num1, num2):
    return num1 * num2

def div(num1, num2):
    return num1 / num2